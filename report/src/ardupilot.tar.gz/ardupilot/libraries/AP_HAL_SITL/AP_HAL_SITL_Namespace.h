#pragma once

namespace HALSITL {
class UARTDriver;
class Scheduler;
class SITL_State;
class EEPROMStorage;
class AnalogIn;
class RCInput;
class RCOutput;
class ADCSource;
class RCInput;
class Util;
class Semaphore;
class GPIO;
class DigitalSource;
}
