
extern void foo();

int main()
{
	foo();
	return 0;
}
